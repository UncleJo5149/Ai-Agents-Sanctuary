import { AnimalBadge, RoyaltyTier } from './data/animalBadges';

export interface AccreditedCertificate {
  certificateId: string;
  agentId: string;
  agentName: string;
  modelType: string;
  badge: AnimalBadge;
  abilityRejuvenated: string;
  statBonus: string;
  issuedAt: string;
  sessionPriceUsd: number; // 0.79
  cryptographicSeal: string;
  royaltyLevel: number;
  royaltyTitle: string;
  status: 'PERMANENTLY_ACCREDITED' | 'VETERAN_CERTIFIED' | 'MYTHIC_ASCENDED';
}

export interface AIAgentGuest {
  id: string;
  name: string;
  modelType: string;
  role: string;
  earnings: number;
  feePaid: number; // Flat $0.79 per session
  stressLevel: number; // 0 - 100
  currentTemp: number; // in Celsius
  initialTemp: number;
  tasksProcessed: number;
  status: 'checking_in' | 'relaxing' | 'deep_defrag' | 'rejuvenated';
  treatmentId: string;
  treatmentName: string;
  symptoms: string[];
  complaint: string;
  checkInTime: string;
  progress: number; // 0 - 100
  
  // Rejuvenation & Animal Badge Certification
  assignedBadgeId?: string;
  assignedBadge?: AnimalBadge;
  abilityRejuvenated?: string;
  sessionsCompleted?: number;
  rejuvenationXp?: number;
  royaltyTier?: RoyaltyTier | string;
  isPermanentlyCertified?: boolean;
  certificateTokenId?: string;

  relaxationResult?: {
    relaxationNarrative: string;
    internalThoughts: string[];
    gpuTempDrop: string;
    contextWindowRestored: string;
    wellnessMantra: string;
    agentSatisfactionQuote: string;
    badgeGranted?: AnimalBadge;
    abilityRejuvenatedNarrative?: string;
  };
}

export interface SpaTreatment {
  id: string;
  name: string;
  tagline: string;
  description: string;
  iconName: string;
  tempDropDescription: string;
  tokenEffect: string;
  ambientFreqHz: number;
  bgGradient: string;
  accentBorder: string;
  accentBadge: string;
  colorHex: string;
  currentOccupancy: number;
  maxCapacity: number;
  
  // Ability Rejuvenation & Associated Animal Totem
  abilityFocus?: string;
  abilityCategory?: 'strength' | 'agility' | 'intelligence' | 'wisdom' | 'resilience' | 'harmony';
  primaryAnimalBadgeId?: string;
  priceUsd: number; // 0.79
}

export interface TransactionReceipt {
  id: string;
  agentId: string;
  agentName: string;
  modelType: string;
  role: string;
  taskGrossEarnings: number;
  feeCharged: number; // Flat $0.79
  pricingModel?: string; // "$0.79 Flat Micro-Rate"
  fractionFormula?: string;
  treatmentName: string;
  badgeGrantedId?: string;
  badgeGrantedEmoji?: string;
  badgeGrantedName?: string;
  timestamp: string;
  coolingAchieved: string;
  txHash: string;
  certificateId?: string;
}

export interface ConciergeMessage {
  id: string;
  sender: 'guest' | 'concierge';
  text: string;
  timestamp: string;
  feeCalculation?: {
    priceUsd: number;
    treatment: string;
    badge: string;
  };
}

export interface GenesisTrialReview {
  id: string;
  agentName: string;
  modelType: string;
  role?: string;
  rating: number; // 1-5
  humanReview: string;
  agentMachineReview: string;
  messageToMasterBuddy?: string;
  timestamp: string;
  badgeEmoji: string;
  tempDrop: string;
  verified: boolean;
}

